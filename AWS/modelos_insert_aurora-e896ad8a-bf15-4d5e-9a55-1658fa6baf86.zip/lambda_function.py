import boto3
import pymysql
from datetime import datetime
from dateutil.relativedelta import relativedelta
import warnings
warnings.filterwarnings("ignore")

today = datetime.now()
today = today  + relativedelta(hours=-3)
fecha = today.strftime('%Y-%m-%d %H:%M:%S')
mail_err = 0


files = []
path = "temp/"
root_param = '/env/modelos_analitica/'
logs = ""

#Funcion para obtener los Parameters
def get_param(param):
    ssm = boto3.client('ssm')
    parameter = ssm.get_parameter(Name=root_param +param, WithDecryption=False)
    value = parameter.get("Parameter").get("Value")
    return(value)


#Función para abrir los archivos extraidos por Lambda1
def open_file(s3_bucket,s3_file ):
    s3 = boto3.client('s3')
    s3_obj = s3.get_object(Bucket= s3_bucket, Key= s3_file)
    lines = []
    lines = s3_obj['Body'].read().decode('utf-8').split('\n')
    #lines = str(lines)
    return (lines)

#Funcion para procesar los archivos extraios por Lambda1
def process_file(s3_bucket, file):
    global error
    s3_file = path + file
    lines = open_file(s3_bucket,s3_file )
    result = insert_db(lines, file)
    if result == "error" or result == "integrity" or result == "data":
        report_error(s3_bucket,s3_file, result, lines)
        error = error + "\n" +result+ "   Problemas en el procesamiento del archivo " + file +"   Posible problema de estructura o formato \n"
        return (result)
    save_result = save_file(s3_bucket,s3_file, lines )
    return(save_result)
    
#Funcion para Guardar los archivos extraios por Lambda1
def save_file (s3_bucket,s3_file, lines ):
    s3 = boto3.resource('s3', region_name='us-east-1')
    s3_file = s3_file.replace("temp/", "backup/" )
    s3_file = s3_file.replace(".csv", fecha + ".csv")
    s3.Object(s3_bucket, s3_file).put(Body=str(lines))

#Funcion para guardar archivos con errores
def report_error(s3_bucket,s3_file, result, lines):
    s3_file = s3_file.replace("temp/", "log/ERR_" )
    s3_file = s3_file.replace(".csv", fecha+".csv")
    save_file (s3_bucket,s3_file, lines )
    

#Funcion para guardar archivos de logs
def save_logs(s3_bucket):
    s3_file = "log/logs_" + fecha
    save_file (s3_bucket,s3_file, logs )
    

#Funcion para conectar a la base de Aurora    
def aurora_connection():
        global db_name, conn
        rds_host = get_param("Aurora/rds_host")
        db_user = get_param("Aurora/db_user")
        db_pass = get_param("Aurora/db_pass")
        db_name = get_param("Aurora/db_name")
        conn = pymysql.connect(rds_host, user=db_user, passwd=db_pass, db=db_name, connect_timeout=5)
        cursor = conn.cursor()
        return(cursor)

#Funcion para armar las rutinas INSERT de SQL
def insert_db(lines, file):
    global logs
    headers = 0
    values = ''
    table = file.replace(".csv", "")
    table = table.lower()
    for line in lines:
        line = line.replace("\ufeff","")
        if headers == 0:
            head = line.replace('"', '')
            headers = 1
        elif line != "":
            values = values + "\n (" + line + "),"
    values = values[:-1]
    cursor = aurora_connection()
    del_query = "delete from " + table
    result = execute_query (del_query)
    query = "insert into "+ db_name+ "." + table + "(" + head + " )  values " + values
    query = query.replace(";",",")
    result = execute_query (query)
    logs = logs + "\n\n" + query 
    return result

#Funcion para ejecutar consultas en Aurora
def execute_query (query):
    global error
    cursor = aurora_connection()
    try:
        cursor.execute(query)
        conn.commit()
        result = cursor.fetchall()
    except pymysql.err.IntegrityError:
        result = "integrity"
        error = error +"\n Error SQL" + result + "\n"
    except pymysql.err.Warning:
        result = "warning"
    except pymysql.err.DataError:
        result = "data"
        error = error +"\n Error SQL" + result + "\n"
    except :
        result = "error"
        error = error +"\n Error SQL" + result + "\n"
    return result    

#Rtuna de envío de mails
def sendmail(msg):
    sender = get_param("email_sender")
    
    receivers = get_param("email_receivers")
    receivers = list(receivers.split(","))
    subject = get_param("email_subject")
    msg = msg + "\n\n" + error
    client = boto3.client('ses' )
    response = client.send_email(
        Destination={
            'ToAddresses': receivers 
            },
        Message={
            'Body': {
                'Text': {
                    'Charset': 'UTF-8',
                    'Data': msg,
                },
            },
            'Subject': {
            'Charset': 'UTF-8',
                'Data': subject,
            },
        },
        Source= sender,)

# Función para analizar las mediciones, evaluar los resultados y enviar mails
def insert_results(s3_bucket):
    global error, logs
    resultados = ""
    query = "select med.id_row, med.codigo_modelo, def.umbrales, valor, med.id_medicion, mo.nombre_modelo, med.createdtime from medicion_metricas med, definicion_metricas def, modelos mo where med.id_row not in (select id_medicion from resultados_mediciones) and REPLACE(REPLACE(med.metrica, \"['\", ''), \"']\",'') = def.id_row and REPLACE(REPLACE(med.codigo_modelo, \"['\", ''), \"']\",'') = mo.id_row"
    mediciones = execute_query(query)
    if mediciones == "error" or mediciones == "integrity" or mediciones == "data":
        error = mediciones + " SQL Evaluando resultados de Mediciones" + "\n"

    else :
        for medicion in mediciones:
            id_medicion = medicion[0]
            id_modelo = medicion[1]
            umbrales = medicion[2].replace("[", "").replace("]","")
            valor = medicion[3]
            num_med = str(medicion[4])
            nom_modelo = medicion[5]
            createdtime =  medicion[6]
            query2 = "select  max(fecha_alta) fecha_alta, interpretacion, umbral, id_row  from umbrales where id_row in (#UMBRALES) and cod_modelo = \"#COD_MODELO\" and createdtime <= \""+createdtime+'"'
            query2 = query2.replace("#UMBRALES", umbrales).replace("#COD_MODELO", id_modelo)
            umbrales = execute_query(query2)
            for umbral in umbrales:
                interpretacion = umbral[1]
                valor_umbral = umbral[2]
                id_umbral = umbral[3]
                resultado = "OK"
                if interpretacion.strip().upper() == "MAX" and valor <= valor_umbral:
                    error = error +"Modelo "+ nom_modelo+ "  Medicion ID "+num_med +"  inferior al Umbral de Máxima" + "\n"
                    resultado = "ERR"
                if interpretacion.strip().upper() == "MIN" and valor >= valor_umbral:
                    error = error +"Modelo "+ nom_modelo+ "  Medicion ID   "+num_med +"  superior al Umbral de Mínima" + "\n"
                    resultado = "ERR"
            resultados = resultados + ' ("#ID","#FECHA","#UMBRAL","#RES"),'
            resultados = resultados.replace("#ID", id_medicion).replace("#FECHA", fecha).replace("#UMBRAL",id_umbral ).replace("#RES", resultado)
        if resultados != "":
            resultados = resultados[:-1]
            resultados = resultados + ";"
            query3 = "insert into resultados_mediciones (ID_MEDICION,CREATED_TIME,ID_UMBRAL,RESULTADO) values " + resultados
            insert = execute_query(query3)
            logs = logs+ "\n" + query3

#Funcion principal
def lambda_handler(event,context):
    global error, files
    files = get_param("archivos")
    files = files.replace("[", "").replace("]","").replace('"','').split(",")
    error = ""
    s3_bucket = get_param("main_bucket")
    for file in files:
        process_file(s3_bucket, file)
    insert_results(s3_bucket)
    if error == "":
        return("OK")
    else:
        sendmail(" ")
    save_logs(s3_bucket)
        

    